jQuery( document ).ready(function() {
	var table = jQuery('#example').dataTable({			
			 "bProcessing": true,
			 "sAjaxSource": "pagination_data.php",
			 "bPaginate":true,
			 "sPaginationType":"full_numbers",
			 "iDisplayLength": 5,
			 "bLengthChange":false,	
			 "bFilter": false,			 
			 "aoColumns": [
					{ mData: 'Empid' } ,
					{ mData: 'Name' },
					{ mData: 'Salary' }
			]
	});   
});